import {Component} from '@angular/core';

@Component({
    selector:'course',
    template:'<h2> Angular </h2>'
})
export class CourseComponent{

}